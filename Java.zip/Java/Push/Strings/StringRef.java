package Strings;

public class StringRef {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String s1 = "hello";
//		String s2 = "world";
//		if(s1 == s2) {
//			System.out.println("yes");
//		}else {
//		System.out.println("no");
		
		String s1 = new String("hello");
        String s2 = new String ("hello");
		if(s1.equals(s2)) {
			System.out.println("yes");
		}else {
		System.out.println("no");
		}

	}

}

