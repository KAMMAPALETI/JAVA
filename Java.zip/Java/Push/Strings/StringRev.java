package Strings;

public class StringRev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer revstr = new StringBuffer("kushalmadineni");
		System.out.print(revstr.reverse());
		
		

	}

}
