package Strings;

public class StringBuff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer s1 = new StringBuffer("kushal");
//		System.out.println(s1);
////		System.out.println(s1.charAt(2));
////		s1.setCharAt(2,'i');
////		System.out.println(s1);
////		s1.deleteCharAt(7);
////		System.out.println(s1);
////		
////		s1.insert(8,"good");
////		System.out.println(s1);
//		s1.insert(0,8);
//		System.out.println(s1);
//		s1.delete(2,6);
//		System.out.println(s1);
//		System.out.println(s1.reverse());
//		System.out.println(s1);
//		
//		s1.setLength(3);
//		System.out.println(s1);
		
		System.out.print(s1.append("madineni").reverse().length());
		
//		
		
		
	
		
		
		
		
		
		
		
		
		

	}

}
