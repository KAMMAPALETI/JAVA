package Inheritance;
class Parent1{
	void fun1() {
		System.out.println("Eww");
	}
}
class Parent2{
	void fun1() {
		System.out.println("Eww");
	}
}
//class Child extends Parent1, 
//Parent2{
//	
//}


public class MultipleInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Child c = new Child();
//		c.fun1();

	}

}
